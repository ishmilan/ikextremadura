# v0.0.8
## 02/02/2018

1. [](#improved)
   * Updated php dependencies
1. [](#bugfix)
   * Fix Undefined variable: compressor (default mode: 'default')
1. [](#new)
   * Added language support in Admin

# v0.0.7
## 12/28/2017

1. [](#bugfix)
   * Updated WyriHaximus/HtmlCompress to 1.3.1 (fix a bug with )
1. [](#new)
   * Added option in admin to choose compression mode (default compress JS and CSS but doesn't do it aggressively to get the smallest size.Fastest only compresses HTML and ignores the rest. Smallest compress everything aggressively to get the smallest size.)

# v0.0.6
## 12/28/2017

1. [](#improved)
   * Updated WyriHaximus/HtmlCompress to 1.3.0 (now minify JSON-LD)

# v0.0.5
## 11/13/2017

1. [](#improved)
   * Add WyriHaximus/HtmlCompress (now minify html / css / js by default)
   * Removed options in admin to toggle inline CSS minifier
   * Removed options in admin to toggle inline JS minifier

# v0.0.4
## 10/20/2017

1. [](#improved)
   * Fixed changelog

# v0.0.3
## 10/19/2017

1. [](#bugfix)
   * Fixed JS enable/disable option
   * Fixed missing hyphen to install instructions

# v0.0.2
## 08/18/2017

1. [](#new)
   * Added options in admin to toggle inline CSS minifier
   * Added options in admin to toggle inline JS minifier
   * Added french language

# v0.0.1
## 07/01/2017

1. [](#new)
   * ChangeLog started...
